from .models import Booking
from django import forms
from django.shortcuts import render
# from .forms import BookingForm

class BookingForm(forms.ModelForm):
    class Meta:
        model = Booking
        fields = "__all__"

def bookings(request):
    if request.method == 'POST':
        form = BookingForm(request.POST)
        if form.is_valid():
            form.save()
            return ('bookings')
    else:
        form = BookingForm()
    return render(request, 'booking.html', {'form': form})